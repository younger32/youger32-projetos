let player;
let obstacles = [];
let gameOver = false;

function setup() {
  createCanvas(400, 400);
  player = new Player();
}

function draw() {
  background(220);

  if (!gameOver) {
    player.update();
    player.display();

    if (frameCount % 60 === 0) {
      obstacles.push(new Obstacle());
    }

    for (let i = obstacles.length - 1; i >= 0; i--) {
      obstacles[i].update();
      obstacles[i].display();

      if (obstacles[i].hits(player)) {
        gameOver = true;
      }

      if (obstacles[i].offscreen()) {
        obstacles.splice(i, 1);
      }
    }

    player.autoDodge(obstacles); // Função de defesa automática
  } else {
    textAlign(CENTER, CENTER);
    textSize(32);
    fill(0);
    text('Game Over', width / 2, height / 2);
  }
}

class Player {
  constructor() {
    this.x = width / 2;
    this.y = height - 50;
    this.size = 50;
    this.speed = 5;
    this.dodgeDistance = 100; // Distância para começar a desviar
  }

  update() {
    // Controle do jogador com setas
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }

    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }

    this.x = constrain(this.x, 0, width - this.size);
  }

  autoDodge(obstacles) {
    for (let i = 0; i < obstacles.length; i++) {
      let obs = obstacles[i];

      // Se o obstáculo estiver perto e alinhado horizontalmente, o jogador desvia
      if (
        obs.y > this.y - this.dodgeDistance &&
        obs.y < this.y && // Se o obstáculo estiver acima do jogador
        abs(obs.x - this.x) < this.size // Se estiver muito próximo horizontalmente
      ) {
        // Desviar para a esquerda ou direita dependendo da posição
        if (obs.x < this.x) {
          this.x += this.speed * 2; // Desviar para a direita
        } else {
          this.x -= this.speed * 2; // Desviar para a esquerda
        }
      }
    }
  }

  display() {
    fill(0, 0, 255);
    rect(this.x, this.y, this.size, this.size);
  }
}

class Obstacle {
  constructor() {
    this.x = random(width);
    this.y = 0;
    this.size = 40;
    this.speedY = random(2, 6); // Velocidade vertical aleatória
    this.speedX = random(-2, 2); // Velocidade horizontal aleatória
  }

  update() {
    this.y += this.speedY;
    this.x += this.speedX;

    // Rebater nas paredes
    if (this.x < 0 || this.x > width - this.size) {
      this.speedX *= -1;
    }
  }

  display() {
    fill(255, 0, 0);
    rect(this.x, this.y, this.size, this.size);
  }

  offscreen() {
    return this.y > height;
  }

  hits(player) {
    return (
      player.x < this.x + this.size &&
      player.x + player.size > this.x &&
      player.y < this.y + this.size &&
      player.y + player.size > this.y
    );
  }
}
